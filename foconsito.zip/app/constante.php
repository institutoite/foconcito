<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class constante extends Model
{
    protected $fillable=[
            'constante',
            'valor'
        ];
}
