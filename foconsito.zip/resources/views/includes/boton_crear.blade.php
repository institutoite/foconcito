<div class="row">

    <div class="centrado" >
    <a href="#" class="btn btn-danger btn-sm text-center centrado">Cancelar</a>
    </div>

    <div class="centrado" >
    <button type="submit" id="guardar" class="btn btn-success btn-sm centrado">Guardar</button>        
    </div>


</div>


