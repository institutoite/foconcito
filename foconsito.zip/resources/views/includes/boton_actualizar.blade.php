<div class="row">
    <div class="col-3">
    </div>
    <a href="{{route('home')}}" class="btn btn-danger col-2">Cancelar</a>
     <div class="col-2"></div>
    <button type="submit" class="btn btn-success btn-sm col-2">Actualizar</button>
    <div class="col-3">
    </div>
</div>
