
<a href="{{route('pago_mostrar', $id)}}" class="btn-accion-tabla tooltipsC mr-2" title="Ver este Pago">
    <i class="fa fa-fw fa-eye text-primary"></i>
</a>




