
<a href="{{route('orden_mostrar', $id)}}" class="btn-accion-tabla tooltipsC mr-2" title="Ver detalle de esta Orden">
    <i class="fa fa-fw fa-eye text-primary"></i>
</a>
