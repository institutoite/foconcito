
<a href="{{route('click_mostrar', $id)}}" class="btn-accion-tabla tooltipsC mr-2" title="Ver esta click">
    <i class="fa fa-fw fa-eye text-primary"></i>
</a>
