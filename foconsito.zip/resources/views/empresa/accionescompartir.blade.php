<a href="{{route('empresa_enviar_empresa')}}" class="btn-accion-tabla tooltipsC" title="Compartir">
    <i class="fas fa-share-alt-square"></i>
</a>

<a href="{{route('empresa_enviar_empresa')}}" class="btn-accion-tabla tooltipsC" title="Compartir">
    <i class="fab fa-whatsapp-square"></i>
</a>

