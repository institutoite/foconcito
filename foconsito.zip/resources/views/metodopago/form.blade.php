<div class="row"> 
    <div class="input-group mb-3 col-12" >
        <input  type="text" name="metodo" class="form-control" value="{{old('metodo',$metodopago_a_editar->metodo ?? '')}}" placeholder="Ingrese un método de pago">
    </div>
</div>
