
<div class="row"> 
    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 input-group mb-3" >
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 form-group mb-3" >
                <input  type="text" name="empresa" class="form-control" value="<?php echo e(old('empresa',$empresa_a_editar->empresa ?? '')); ?>" placeholder="Ingrese el nombre de su empresa">
                 <small id="nombreHelp" class="form-text text-muted">Favor introduzca el nombre de su empresa</small>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 input-group mb-2" >
                <select class="form-control" name="categoria_id" id="categoria">
                    <option value="">Seleccione una Categoría</option> 
                        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(isset($empresa_a_editar)): ?>     
                                <option value="<?php echo e($item->id); ?>" <?php echo e($item->id==$empresa_a_editar->categoria_id ? 'selected':''); ?> ><?php echo e($item->categoria); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($item->id); ?>" <?php echo e(old('categoria_id') == $item->id ? 'selected':''); ?> ><?php echo e($item->categoria); ?></option>
                            <?php endif; ?> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 input-group mb-2" >
                <select class="form-control" name="pais_id" id="country">

                        <option value="" selected> Elija una país</option>
                    <?php $__currentLoopData = $paises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pais): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(isset($empresa_a_editar)): ?>     
                                    <option value="<?php echo e($pais->id); ?>" <?php echo e($pais->id==$empresa_a_editar->pais_id ? 'selected':''); ?> ><?php echo e($pais->pais); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($pais->id); ?>" <?php echo e(old('pais_id') == $pais->id ? 'selected':''); ?> ><?php echo e($pais->pais); ?></option>
                                <?php endif; ?> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 input-group mb-2" >
                <select class="form-control" name="ciudad_id" id="city">
                    <?php if(isset($empresa_a_editar)): ?>
                        <?php $__currentLoopData = $ciudades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $citys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(isset($empresa_a_editar)): ?>     
                               <option value="<?php echo e($citys->id); ?>" <?php echo e($citys->id==$empresa_a_editar->ciudad_id ? 'selected':''); ?> ><?php echo e($citys->ciudad); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($citys->id); ?>" <?php echo e(old('ciudad_id') == $citys->id ? 'selected':''); ?> ><?php echo e($citys->ciudad); ?></option>
                            <?php endif; ?> 
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?> 
                        <option value=""> Elija una ciudad</option>
                    <?php endif; ?>
                </select>
                <a href="<?php echo e(route('ciudad_crear')); ?>"> <i class="fas fa-plus-circle fa-2x text-success"></i> </a>
            </div>        
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 input-group mb-2" >
                <select class="form-control" name="zona_id" id="zone">
                    <?php if(isset($empresa_a_editar)): ?>
                        <?php $__currentLoopData = $zonas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zones): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($zones->id); ?>" <?php echo e($zones->id==$empresa_a_editar->zona_id ? 'selected':''); ?> ><?php echo e($zones->zona); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?> 
                        <option value=""> Elija una Zona</option>
                    <?php endif; ?>
                </select>
                <a href="<?php echo e(route('zona_crear')); ?>"> <i class="fas fa-plus-circle text-success fa-2x"></i> </a>
            </div>
            <?php if(isset($empresa_a_editar)): ?>
            <?php else: ?>
                <?php if(count($ordenes)==0): ?>
                    <div class="alert alert-danger" role="alert">
                        <strong> No existen ordenes activas </strong> <a href="<?php echo e(route('pago_formas')); ?>" class=""> <i class="fas fa-cart-plus"></i>Conseguir orden</a>
                    </div>
                <?php endif; ?>
                
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 form-group mb-3">
                   
                    <select class="form-control" name="orden_id" id="orden_id">
                            <option value="" selected> Una orden de pago</option>
                        <?php $__currentLoopData = $ordenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orden): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(isset($empresa_a_editar)): ?>     
                                        <option value="<?php echo e($orden->id); ?>" <?php echo e($orden->id==$empresa_a_editar->orden_id ? 'selected':''); ?> ><?php echo e('ORDEN-'.$orden->created_at); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($orden->id); ?>" <?php echo e(old('orden_id') == $orden->id ? 'selected':''); ?> ><?php echo e('ORDEN- '.$orden->id.$orden->created_at); ?></option>
                                    <?php endif; ?> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <small id="nombreHelp" class="form-text text-muted">Favor la Dirección de su empresa</small>
                    
                </div>
                
            <?php endif; ?>
        </div>
    </div>   

    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 input-group mb-3" >
        <div class="row"> 
            <div class="col-12">
                <strong>Suba una imagen de perfil o logotipo(Opcional)</strong>
            </div>
        </div>
        
        <div class="row"> 
            <div class="col-12">
                <input type="file" accept=".png, .bmp, .jpg, .jpeg, .gif" name="logo" id="logo" data-initial-preview="<?php echo e(isset($empresa_a_editar->logo) ? Storage::url($empresa_a_editar->logo) : Storage::url('logos/sinlogo.png')); ?>"  data-classButton="btn btn-primary" data-input="false" data-classIcon="icon-plus">
            </div>
        </div>
        
    </div>   

    
</div>

<div class="form-group">
   
    <input  type="text" name="direccion" class="form-control" value="<?php echo e(old('direccion',$empresa_a_editar->direccion ?? '')); ?>" placeholder="ingrese la direccion de su empresa">    
    <small id="nombreHelp" class="form-text text-muted">Favor la Dirección de su empresa</small>
</div>


<div class="form-group">
   
    <textarea  class="form-control" name="detalle" id="detalle" cols="30" rows="10">
            <?php echo e(old('detalle', $empresa_a_editar->detalle ?? '')); ?>

        </textarea>
    <small id="nombreHelp" class="form-text text-muted">Favor introduzca el detalle de su producto</small>
</div>




<?php /**PATH C:\xampp\htdocs\foconsito\resources\views/empresa/form.blade.php ENDPATH**/ ?>