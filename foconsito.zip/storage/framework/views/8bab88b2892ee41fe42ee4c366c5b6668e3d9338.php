<?php $__env->startSection('titulo'); ?>
  Mostrar Mensaje
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/emojionearea/3.4.2/emojionearea.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/emojione@4.0.0/extras/css/emojione.min.css"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?> 
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('mensaje_mostrar')): ?>
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body table-responsive">
                                <!-- Horizontal Form -->
                            <?php echo $__env->make('includes.form-error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo $__env->make('includes.mensaje', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>             
                            
                            
                            <div class="card bg-transparent mb-3" style="max-width: 100%;">
                                <div class="card-header text-center"> DETALLE MENSAJE</div>
                                <div class="card-body">
                                    
                                    <table class="table table-bordered table-hover table-striped" id="mensaje">
                                        <thead class="bg-cyan">
                                            <tr>
                                                <th>ATRIBUTO</th>
                                                <th>VALOR</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>ID</td>
                                                <td><?php echo e($mensaje->id); ?></td>
                                            </tr>
                                            <tr>
                                                <td>NOMBRE</td>
                                                <td><?php echo e($mensaje->nombre); ?></td>
                                            </tr>
                                            <tr>
                                                <td>MENSAJE</td>
                                                <td> 
                                                    <?php echo e($mensaje->mensaje); ?>

                                                </td>
                                            </tr>
                                            <tr>
                                                <td>CREADO</td>
                                                <td><?php echo e($mensaje->created_at); ?></td>
                                            </tr>
                                            <tr>
                                                <td>ACUALIZADO</td>
                                                <td><?php echo e($mensaje->updated_at); ?></td>
                                            </tr>
                                        </tbody>      
                                    </table>
                                </div>
                            </div>
                        </div>    
                    </div>
                </div>
            </div> <!-- FIN ROW -->
        </div>  
    <?php else: ?> 
        <?php echo $__env->make('includes.sinpermiso', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('codigojs'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/emojionearea/3.4.2/emojionearea.js"></script>
    <script src="<?php echo e(asset("dist/js/alertas.js")); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/emojione@4.0.0/lib/js/emojione.min.js"></script>

    <script type="text/javascript">
    $(document).ready(function(){
           var Celda =$('#mensaje tbody').find('tr').first().next().next().children('td').first().next();
               Celda.html(emojione.shortnameToImage(Celda.text()));   
    });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\foconsito\resources\views/mensaje/mostrar.blade.php ENDPATH**/ ?>