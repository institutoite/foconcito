<?php $__env->startSection('titulo'); ?>
  Listar Empresas
<?php $__env->stopSection(); ?>


<?php $__env->startSection('contenido'); ?>     
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('empresa_config')): ?>
        <?php
            $i=1; // variable para crear un nuevo row o añadir a contunuacion de 4 en 4
        ?>
        <table class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th>Nº</th>
                    <th>EMPRESA</th>
                    <th> ACCIONES </th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($empresa->empresa); ?></td>
                    <td> <a href="<?php echo e(route('telofempresa_listar',$empresa->id)); ?>" class="btn btn-success"> Gestionar Teléfonos </a> </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>

            </tfoot>
        </table>
        
    <?php else: ?> 
        <?php echo $__env->make('includes.sinpermiso', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('codigojs'); ?>
    <script src="<?php echo e(asset("dist/js/alertas.js")); ?>"></script>
<script>

     $(document).ready(function() {
        /*$('.botonaccion').on('click', 'a', function(e) { 
          e.preventDefault();  
		  $(this).css('color', 'red'); 
        });*/
        
    });
    $('#tigo').fileinput({
        language:'es',
        allowedFileExtensions:['jpg','jpeg','png'],
        maxFileSize:2000,
        showUpload:false,
        showClose:false,
        initialPreviewAsData:true,
        dropZoneEnabled:true,
        theme:"fas",
    });     
</script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\foconsito\resources\views/telofempresa/empresas.blade.php ENDPATH**/ ?>