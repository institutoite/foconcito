
<div class="row">
    <div class="col-12 input-group mb-2" >
        <select class="form-control" name="pais_id" id="country">
            <option value=""> Elija una país</option>
            <?php $__currentLoopData = $paises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pais): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(isset($ciudad_a_editar)): ?>     
                    <option  value="<?php echo e($pais->id); ?>" <?php echo e($pais->id==$ciudad_a_editar->pais_id ? 'selected':''); ?>><?php echo e($pais->pais); ?></option>     
                <?php else: ?>
                    <option value="<?php echo e($pais->id); ?>" <?php echo e(old('pais_id') == $pais->id ? 'selected':''); ?> ><?php echo e($pais->pais); ?></option>
                <?php endif; ?> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</div>
 
<div class="row"> 
    <div class="input-group mb-3 col-12" >
        <input  type="text" name="ciudad" class="form-control" value="<?php echo e(old('ciudad',$ciudad_a_editar->ciudad ?? '')); ?>" placeholder="ingrese una ciudad">
    </div>
</div>

<?php /**PATH C:\xampp\htdocs\foconsito\resources\views/ciudad/form.blade.php ENDPATH**/ ?>