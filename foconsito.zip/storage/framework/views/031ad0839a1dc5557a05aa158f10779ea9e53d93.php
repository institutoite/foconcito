<a href="<?php echo e(route('persona_editar', $id)); ?>" class="btn-accion-tabla tooltipsC mr-2" title="Editar esta Persona">
    <i class="fa fa-fw fa-edit text-primary"></i>
</a>

<a href="<?php echo e(route('persona_mostrar', $id)); ?>" class="btn-accion-tabla tooltipsC mr-2" title="Ver esta Persona">
    <i class="fa fa-fw fa-eye text-primary"></i>
</a>

<a href="<?php echo e(route('telefono_listar', $id)); ?>" class="btn-accion-tabla tooltipsC mr-2" title="Ver esta Persona">
    <i class="fa fa-fw fa-phone text-primary"></i>
</a>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('persona_eliminar')): ?>
    <form action="<?php echo e(route('persona_eliminar', $id)); ?>" id="form<?php echo e($id); ?>" class="d-inline formulario" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field("delete"); ?>
        <button name="btn-eliminar" id="<?php echo e($id); ?>" type="submit" class="btn eliminar" title="Eliminar esta Persona">
            <i class="fa fa-fw fa-trash text-danger"></i>   
        </button>
    </form>     
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\foconsito\resources\views/persona/acciones.blade.php ENDPATH**/ ?>