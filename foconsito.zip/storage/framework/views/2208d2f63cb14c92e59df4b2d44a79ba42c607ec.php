<?php $__env->startSection('titulo'); ?>
  Listar Teléfonos
<?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>
     <link rel="stylesheet" href="<?php echo e(asset("dist/css/custom.css")); ?>">
    <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.4/css/responsive.dataTables.min.css">
                                 
<?php $__env->stopSection(); ?>


<?php $__env->startSection('contenido'); ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('empresa_listar')): ?>
        <div class="row">
            <div class="col-lg-12">  
                <div class="card-header border-success d-flex mt-3">
                    <h3 class="card-title">NUMEROS TELEFONICOS: <strong> <?php echo e($empresa->empresa); ?> </strong> </h3>
                    <h3 class="card-title ml-auto"><a class="btn bg-cyan" href="<?php echo e(route('telofempresa_crear',$empresa->id)); ?>"><i class="fas fa-plus-circle"></i>Agreagar mas Teléfonos</a></h3>
                </div>
                <div class="card-body"> 
                    <table id="telofempresas" class="table table-hover table-bordered table-striped display responsive nowrap" width="100%">
                        <thead class="bg-cyan">
                        
                            <th>#</th>
                            <th>Numero</th>
                            <th>Detalle</th>
                            <th>Creado</th>
                            <th width="120px">Contactar</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $telefonos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $telefono): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    
                                    <td><?php echo e($telefono->prefijo.$telefono->numero); ?></td>
                                    <td><?php echo e($telefono->detalle); ?></td>
                                    <td><?php echo e($telefono->created_at); ?></td>

                                    <td>
                                        <a href="<?php echo e(route('telofempresa_editar', $telefono->id)); ?>" class="btn-accion-tabla tooltipsC mr-2" title="Editar este número">
                                            <i class="fa fa-fw fa-edit text-primary"></i>
                                        </a>
                                        
                                            <form action="<?php echo e(route('telofempresa_eliminar',['id' =>$telefono->id,'empresa_id'=>$empresa->id])); ?>" id="form<?php echo e($telefono->id); ?>" class="d-inline formulario" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field("delete"); ?>
                                                <button name="btn-eliminar" id="<?php echo e($telefono->id); ?>" type="submit" class="btn eliminar" title="Eliminar este Número">
                                                    <i class="fa fa-fw fa-trash text-danger"></i>   
                                                </button>
                                            </form> 

                                        
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <?php echo e($telefonos->render()); ?>

            </div>
        </div> <!-- FIN ROW -->
    <?php else: ?> 
        <?php echo $__env->make('includes.sinpermiso', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('codigojs'); ?>
<script src=""></script>
<script src="https://cdn.datatables.net/responsive/2.2.4/js/dataTables.responsive.min.js"></script>
<script type="text/javascript">


$(document).ready(function() {

    $('#telofempresas').DataTable({ 
     
        "responsive": true,
        "columnDefs": [
            { responsivePriority: 1, targets: 1 },
            { responsivePriority: 2, targets: -1 },
        ],
        
        "language":{
            "search":"Buscar",
            "paginate":{
                "next":"Siguiente",
                "previous":"Anterior",
            },
            "lengthMenu": 'Mostrar <select>' +
                                    '<option value="5">5</option>'+
                                    '<option value="10">10</option>'+
                                    '<option value="20">20</option>'+
                                    '<option value="50">50</option>'+
                                    '<option value="-1">Todos</option>'+
                                    '</select> Registros',
            "loadingsRecords":"Cargando....",
            "processing":"Procesando...",
            "emptyTable":"No encontre números telefónicos",
            "infoEmpty":"",
            "infoFiltered":"",
            "zeroRecords":"No hay datos",  
            "info": "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
        }
    })

    $('table').on('click','.eliminar',function (e) {
        
        e.preventDefault();   
        Swal.fire({
            title: 'Estas seguro(a) de eliminar este registro?',
            text: "Si eliminas el registro no lo podras recuperar jamás!",
            icon: 'question',
            showCancelButton: true,
            showConfirmButton:true,
            confirmButtonColor: '#25ff80',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Eliminar..!',
            position:'center',        
        }).then((result) => {
            if (result.value) {
                var $form=$(this).parent();
                $form.append('<input name="_token" type="hidden" value="' + $('meta[name="csrf-token"]').attr('content') + '">');
                console.log('_token');
                $(this).parent().submit();
                Swal.fire(
                'Borrado Correctamente!',
                'El registro fue eliminado definitivamente.',
                'success')
            }else{
                const Toast = Swal.mixin({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 2000,
                    timerProgressBar: true,
                    onOpen: (toast) => {
                        toast.addEventListener('mouseenter', Swal.stopTimer)
                        toast.addEventListener('mouseleave', Swal.resumeTimer)
                    }
                })

                Toast.fire({
                    icon: 'error',
                    title: 'No se eliminó el registro'
                })
            }
        })
});


} );
</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\foconsito\resources\views/telofempresa/index.blade.php ENDPATH**/ ?>