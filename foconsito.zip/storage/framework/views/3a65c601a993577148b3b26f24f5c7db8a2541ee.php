
<a href="<?php echo e(route('pago_mostrar', $id)); ?>" class="btn-accion-tabla tooltipsC mr-2" title="Ver este Pago">
    <i class="fa fa-fw fa-eye text-primary"></i>
</a>




<?php /**PATH C:\xampp\htdocs\foconsito\resources\views/pago/acciones.blade.php ENDPATH**/ ?>