
<div class="row mt-5">
  <div class="col-2"></div>
    <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8">
        <ul class="list-group">
          <li class="list-group-item bg-cyan text-center"><h3> <i class="fas fa-lock"></i></i> SOLO VERSION <span>PRO</span>  </h3></li>
          <li class="list-group-item list-group-item-action list-group-item-info text-center"> <h6 class="display-4">Muestra tu empresa </h6> a las personas que están buscando tus productos o servicios
          <li class="list-group-item list-group-item-action list-group-item-info"></i><i class="fas fa-check float-right text-success fa-1x"></i> <span>Tu determinas el precio(Tu voluntad) para acceder al 100% de las funcionalidades de <strong>Foconcito </strong><del> Bs. 150</del> (Válido para los primeros 50000 usuarios)</span>
          <li class="list-group-item list-group-item-action list-group-item-info"></i><i class="fas fa-check float-right text-success fa-1x"></i> <span>El mundo cambió con la llegada del Covid-19 <strong>Ahora para existir hay digitalizar nuestras empresas</strong> No te quedes atrás</span>
          <li class="list-group-item text-center"></i> <a href="<?php echo e(route('pago_formas')); ?>" class="btn fondo-azul"> <i class="fas fa-cart-plus"></i> Quiero Acceder a version PRO</a> </li> 
        
        </ul>
    </div>
  <div class="col-2"></div>
</div>

<?php /**PATH C:\xampp\htdocs\foconsito\resources\views/includes/sinpermiso.blade.php ENDPATH**/ ?>