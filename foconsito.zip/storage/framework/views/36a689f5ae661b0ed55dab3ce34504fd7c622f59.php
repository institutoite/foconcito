
<div class="row"> 
    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 input-group mb-2" >
        <input  type="text" name="nombre" class="form-control" value="<?php echo e(old('nombre',$persona_a_editar->nombre ?? '')); ?>" placeholder="Ingrese un  nombre">
    </div>

    <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8 input-group mb-2" >
        <input  type="text" name="apellidos" class="form-control" value="<?php echo e(old('apellidos',$persona_a_editar->apellidos ?? '')); ?>" placeholder="Ingrese sus apellidos">
    </div>
    
</div>

<div class="row"> 
    
    <?php if(isset($persona_a_editar)): ?>
        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 input-group mb-2" >
            <label for="">Fecha Nacimiento</label> 
            <input  type="date" name="fechanacimiento" min="1900-01-01" class="form-control" value="<?php echo e(old('fechanacimiento',$persona_a_editar->fechanacimiento->format('Y-m-d') ?? '')); ?>">
        </div>
    <?php else: ?>
        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 input-group mb-2" >
            <label for="">Fecha Nacimiento</label> 
            <input  type="date" name="fechanacimiento" min="1900-01-01" class="form-control" value="<?php echo e(old('fechanacimiento' ?? '')); ?>">
        </div>
    <?php endif; ?>
    
     <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 input-group mb-2" >
        <select class="form-control" name="genero" id="genero">
            <option value=""> Elija tu género</option>
            
                <?php if(isset($persona_a_editar)): ?>      
                    <?php if($persona_a_editar->genero=="MUJER"): ?>
                        <option value="<?php echo e($persona_a_editar->genero); ?>" <?php echo e("MUJER"==$persona_a_editar->genero ? 'selected':''); ?> ><?php echo e($persona_a_editar->genero); ?></option>
                        <option value="HOMBRE">HOMBRE</option>
                    <?php else: ?>
                        <option value="<?php echo e($persona_a_editar->genero); ?>" <?php echo e("HOMBRE"==$persona_a_editar->genero ? 'selected':''); ?> ><?php echo e($persona_a_editar->genero); ?></option>
                        <option value="MUJER" >MUJER</option>
                    <?php endif; ?>
                    
                <?php else: ?>
                    <option value="MUJER" >MUJER</option>
                    <option value="HOMBRE" >HOMBRE</option>
                <?php endif; ?>    
        </select>
     
    </div>


</div>

 <div class="form-group">
    <!--label for="detalle">Pais</label-->
    <select class="form-control" name="pais_id" id="country">
                    <option value=""> Elija un pais</option>
                    <?php $__currentLoopData = $paises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(isset($persona_a_editar)): ?> 
                            <option value="<?php echo e($item->id); ?>" <?php echo e($item->id==$persona_a_editar->pais_id ? 'selected':''); ?> ><?php echo e($item->pais); ?></option>
                        <?php else: ?>
                            <option value="<?php echo e($item->id); ?>" <?php echo e(old('pais_id') == $item->id ? 'selected':''); ?> ><?php echo e($item->pais); ?></option>
                        <?php endif; ?> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
        </select>
    <small id="nombreHelp" class="form-text text-muted">Seleccione pais de Origen del cliente</small>
</div>

 <div class="form-group">
    <!--label for="detalle">Ciudad</label-->
     <select class="form-control" name="ciudad_id" id="city">
                <option value=""> Elija una ciudad</option>
                    <?php $__currentLoopData = $ciudades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(isset($persona_a_editar)): ?> 
                            <option value="<?php echo e($item->id); ?>" <?php echo e($item->id==$persona_a_editar->ciudad_id ? 'selected':''); ?> ><?php echo e($item->ciudad); ?></option>
                        <?php endif; ?> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
    <small id="nombreHelp" class="form-text text-muted">Seleccione ciudad de Origen del cliente</small>
</div>

<div class="form-group">
    <!--label for="detalle">Zona</label-->
      <select class="form-control" name="zona_id" id="zone">
                <option value="">Seleccione una Zona</option> 
                <?php $__currentLoopData = $zonas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(isset($persona_a_editar)): ?> 
                            <option value="<?php echo e($item->id); ?>" <?php echo e($item->id==$persona_a_editar->zona_id ? 'selected':''); ?> ><?php echo e($item->zona); ?></option>
                        <?php endif; ?> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
    <small id="nombreHelp" class="form-text text-muted">Seleccione zona de Origen del cliente</small>
</div>






<div class="row"> 
    <div class="input-group mb-3 col-12" >
        <input hidden  type="text" value="cliente" name="tipo" class="form-control">
        
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\foconsito\resources\views/persona/form.blade.php ENDPATH**/ ?>