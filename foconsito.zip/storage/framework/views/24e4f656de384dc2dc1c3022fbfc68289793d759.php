<?php $__env->startSection('titulo'); ?>
  Busqueda avanzada
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
  <link rel="stylesheet" href="<?php echo e(asset("dist/css/custom.css")); ?>">  
<?php $__env->stopSection(); ?>


<?php $__env->startSection('contenido'); ?>
    
    <p class="text-muted">  <?php echo e($mensaje ?? 'Que estas buscando?'); ?> <a class="float-right text-primary" href="<?php echo e(route('home')); ?>">Búsqueda normal </a></p>  

    


    <img src="<?php echo e(asset("imagenes/buscador.png")); ?>" width="300" alt="">
    <div class="row">
        <form class="form-horizontal col-12" method="GET" action="<?php echo e(route('empresa_buscar_avanzado')); ?>">
          
            <div class="row"> 
                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 input-group mb-2" >
                    <select class="form-control" name="pais_id" id="country" required>
                            <option value="0" <?php if(isset($pais_id)): ?> <?php echo e($pais_id == 0 ? 'selected':''); ?> <?php endif; ?>  > Todos</option>
                                
                                <?php $__currentLoopData = $paises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pais): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(isset($radicatoria)): ?>
                                        <?php if($radicatoria[0]->id==$pais->id): ?>     
                                            <option value="<?php echo e($radicatoria[0]->id); ?>" <?php echo e('selected'); ?> ><?php echo e($pais->pais); ?></option>
                                        <?php else: ?>
                                            <option value="<?php echo e($pais->id); ?>" <?php echo e(old('pais_id') == $pais->id ? 'selected':''); ?> ><?php echo e($pais->pais); ?></option>
                                        <?php endif; ?>  
                                    <?php else: ?>
                                        <?php if($pais_id==$pais->id): ?>     
                                            <option value="<?php echo e($pais_id); ?>" <?php echo e('selected'); ?> ><?php echo e($pais->pais); ?></option>
                                        <?php else: ?>
                                            <option value="<?php echo e($pais->id); ?>" <?php echo e(old('pais_id') == $pais->id ? 'selected':''); ?> ><?php echo e($pais->pais); ?></option>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                
                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 input-group mb-2" >
                    <select class="form-control" name="ciudad_id" id="city" required>
                        <option value="0" selected> Todos</option>
                        <?php if(isset($ciudad_id)): ?>
                            <?php $__currentLoopData = $ciudades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $citys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($citys->id); ?>" <?php echo e($citys->id==$ciudad_id ? 'selected':''); ?> ><?php echo e($citys->ciudad); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?> 
                            <?php $__currentLoopData = $Ciudades_de_pais_radicado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ciudad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($ciudad->id); ?>" <?php echo e(old('ciudad_id') == $ciudad->id ? 'selected':''); ?> ><?php echo e($ciudad->ciudad); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                   
                </div>        
                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 input-group mb-2" >
                    <select class="form-control" name="zona_id" id="zone" required>
                        <option value="0" selected> Todos</option>
                        <?php if(isset($zona_id)): ?>
                            <?php $__currentLoopData = $zonas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zones): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($zones->id); ?>" <?php echo e($zones->id==$zona_id ? 'selected':''); ?> ><?php echo e($zones->zona); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?> 
                            <option value="0"> Elija una Zona</option>
                        <?php endif; ?>
                    </select>
                   
                </div>
            </div>    


                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 input-group mb-2 p-2">
                    <input class="form-control" type="text" required  value="<?php echo e(old('criterio',$criterio ?? '')); ?>" name="criterio" id="criterio" placeholder="Escribe aquí que Busca Ej. Celulares, Ropa, Casa etc"
                    aria-label="Search">
                    <button type="submit" class="btn btn-success btn-sm" id="submit">Buscar <i class="fas fa-search text-white-50" aria-hidden="true"></i> </button>
                </div>
        </form>
    </div>


    
        <?php if(isset($productos)): ?>
    
        <?php
            $i=1;
        ?>
      
         <div class="container">
           
                    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if((($i-1) % 4==0)||($i==1)): ?>
                            <div class="row">
                                
                                    <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 input-group mb-3" >
                                        <div class="card text-white mb-3 borde-oscuro" style="max-width: 36rem;">
                                            <div class="card-header fondo text-center"><?php echo e($producto->titulo); ?></div>
                                                <div class="card-body producto">
                                                    <div class="precio text-center text-white">
                                                            <div class="textoprecio"> Bs. <?php echo e($producto->costo); ?> </div> 
                                                    </div>
                                                    
                                                    <img class="img-thumbnail zoomify" src="<?php echo e(isset($producto->foto) ? Storage::url($producto->foto) : Storage::url('galerias/sinimagenes.jpg')); ?>" alt="<?php echo e($producto->titulo); ?>">
                                                     
                                                </div>
                                                <div class="text-center botonaccion">
                                                    <p class="text-gray cuerpo"> <?php echo e($producto->descripcion); ?></p>
                                                </div>
                                                <div class="row">
                                                    <div class="col-6">
                                                        <div class="row justify-content-center align-content-center">
                                                            <a href="<?php echo e(route('imagen_votar',$producto->id)); ?>" class="btn bg-info btn-sm text-white"><i class="far fa-eye text-white"> Detalle </i></a>
                                                        </div>
                                                    </div>
                                                    <div class="col-6">
                                                        <div class="row justify-content-center align-content-center">
                                                            <a  href="<?php echo e(route('imagen_contactar',$producto->id)); ?>" target="_blank" class="btn bg-success text-white btn-sm"><i class="fab fa-whatsapp text-white"> Contactar</i></a>        
                                                        </div>
                                                    </div>
                                                </div>
                                                <small id="nombreHelp" class="form-text text-muted"><?php echo e($producto->created_at->diffForHumans().' en '.$producto->ciudad."|".$producto->zona."|".$producto->direccion); ?></small>
                                        </div>
                                    </div>
                                
                    <?php else: ?>    
                            
                                <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 input-group mb-3" >
                                    <div class="card text-white mb-3 borde-oscuro" style="max-width: 36rem;">
                                        <div class="card-header fondo borde-cyan text-center"><?php echo e($producto->titulo); ?></div>
                                            <div class="card-body producto">
                                                    <div class="precio text-center text-white">
                                                            <div class="textoprecio"> Bs. <?php echo e($producto->costo); ?> </div> 
                                                    </div>
                                                    
                                                    <img class="img-thumbnail zoomify" src="<?php echo e(isset($producto->foto) ? Storage::url($producto->foto) : Storage::url('galerias/sinimagenes.jpg')); ?>" alt="">
                                                    </a>
                                            </div>
                                            <div class="text-center botonaccion">
                                                <p class="text-gray cuerpo"> <?php echo e($producto->descripcion); ?></p>
                                            </div>
                                            
                                            
                                              
                                            <div class="row">
                                                <div class="col-6">
                                                    <div class="row justify-content-center align-content-center">
                                                        <a href="<?php echo e(route('imagen_votar',$producto->id)); ?>" class="btn bg-info btn-sm text-white"><i class="far fa-eye text-white"> Ver </i></a>
                                                    </div>
                                                </div>
                                                <div class="col-6">
                                                    <div class="row justify-content-center align-content-center">
                                                        <a  href="<?php echo e(route('imagen_contactar',$producto->id)); ?>" target="_blank" class="btn bg-success text-white btn-sm"><i class="fab fa-whatsapp text-white"> Contactar</i></a>
                                                    </div>
                                                </div>
                                            </div>

                                            <small id="nombreHelp" class="form-text text-muted"><?php echo e($producto->created_at->diffForHumans().' en x '.$producto->ciudad."|".$producto->zona."|".$producto->direccion); ?></small>
                                            
                                    </div>
                                </div> 
                                
                        <?php if(($i) % 4 == 0): ?>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php
                        $i=$i+1;    
                    ?>                  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
           
        </div> 
        <?php echo e($productos->appends(['criterio' => $criterio,'pais_id'=>$pais_id,'ciudad_id'=>$ciudad_id,'zona_id'=>$zona_id])->links()); ?> 
    <?php endif; ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('codigojs'); ?>
     <script>
     
    $(document).ready(function(){
        $('#country').on('change', Load_country);
        $('#city').on('change', Load_city);

        $(".cuerpo").each(function(){
            $(this).html($(this).text().substring(0,250)+"...");
        });
    });	
    function Load_country(){
        var country_id = $(this).val();
        console.log(country_id);
        if(!country_id){
            $('#city').html('<option value="">Seleccione una Ciudad </option>');
        return;
        }
        $.get('/api/pais/'+ country_id +'/ciudades',function (data) {
            var html_select='<option value="0">Seleccione una Ciudad </option><option value="0"> Todos</option>';
            for (var i = 0; i < data.length; i++) {
                html_select+='<option value="'+ data[i].id +'">' +data[i].ciudad +'</option>';
                //console.log(html_select);
            }
            $('#city').html(html_select);
        });
    }

    function Load_city(){
        var city_id = $(this).val();
        if(!city_id){
            $('#zone').html('<option value="">Seleccione una Zona </option>');
        return;
        }
        $.get('/api/ciudad/'+ city_id +'/zonas',function (data) {
            var html_select='<option value="0">Seleccione una Zona </option> <option value="0"> Todos</option>';
            for (var i = 0; i < data.length; i++) {
                html_select+='<option value="'+ data[i].id +'">' +data[i].zona +'</option>';
                console.log(html_select);
            }
            $('#zone').html(html_select);
        });
    }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\foconsito\resources\views/empresa/busquedaavanzada.blade.php ENDPATH**/ ?>