<?php $__env->startSection('titulo'); ?>
  Crear Teléfono
<?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('bootstrap-fileinput/css/fileinput.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>  
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('empresa_crear')): ?>
        <div class="row">
            <div class="col-12">
                <?php echo $__env->make('includes.form-error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('includes.mensaje', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>     
                   

                    <div class="card-header bg-cyan mt-3">
                    <h3 class="card-title">REGISTRAR TELEFONOS PARA: <strong><?php echo e($persona->nombre.' '.$persona->apellidos); ?></strong></h3>
                    </div>
                    <div class="card-body"> 
                        <form action="<?php echo e(route('telefono_guardar')); ?>"  id="form-general" enctype="multipart/form-data" class="form-vertical form-" method="POST" autocomplete="on">
                            <?php echo csrf_field(); ?>
                                <?php echo $__env->make('telefono.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php echo $__env->make('includes.boton_crear', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </form>
                    </div> 
                
            </div>    
        </div>
    <?php else: ?> 
        <?php echo $__env->make('includes.sinpermiso', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?> 
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('codigojs'); ?>
<script>
    
    $(document).ready(function(){
        
    });	
</script>
    
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\foconsito\resources\views/telefono/crear.blade.php ENDPATH**/ ?>