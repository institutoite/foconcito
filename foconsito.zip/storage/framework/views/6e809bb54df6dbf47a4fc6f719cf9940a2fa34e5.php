<div class="row mb-3 text-center">
    <div class="col-2">
    </div>

    
    <div class="col-2">
        <a href="<?php echo e(route('imagen_editar', $ima->id)); ?>" class="btn mr-3" title="Editar este producto">
            <i class="fa fa-fw fa-edit text-primary"></i>
        </a>
    </div>
    
    <div class="col-2">

    </div>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('imagen_eliminar')): ?>
        <div class="col-2">
            <form action="<?php echo e(route('imagen_eliminar', $ima->id)); ?>" id="form<?php echo e($ima->id); ?>" class="d-inline formulario" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field("delete"); ?>
                    <button name="btn-eliminar" id="<?php echo e($ima->id); ?>" type="submit" class="btn" title="Eliminar esta imagen"><i class="fa fa-fw fa-trash text-danger"></i>   
                    </button>
            </form>
        </div>
    <?php endif; ?>
</div><?php /**PATH C:\xampp\htdocs\foconsito\resources\views/empresa/accionesgaleria.blade.php ENDPATH**/ ?>