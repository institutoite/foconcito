<div class="row"> 
    <div class="input-group mb-3 col-12" >
        <input  type="text" name="categoria" class="form-control" value="<?php echo e(old('categoria',$categoria_a_editar->categoria ?? '')); ?>" placeholder="ingrese una categoria de negocio">
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\foconsito\resources\views/categoria/form.blade.php ENDPATH**/ ?>