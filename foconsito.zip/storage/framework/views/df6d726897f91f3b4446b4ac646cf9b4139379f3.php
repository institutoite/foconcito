<?php $__env->startSection('titulo'); ?>
  Publicar mis empresas
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>


 
    <div class="row">
        <div class="col-lg-12">  
            <div class="card-header border-success d-flex mt-3">
            <h3 class="card-title">Total ordenes <strong> <?php echo e(count($ordenes_verificadas)); ?></strong> </h3>
                
            </div>
            <div class="card-body"> 
                <table id="pagos" class="table table-bordered table-hover table-striped">
                    <thead>
                        <tr class="bg-cyan">
                            <th>#</th>
                            <th>EMPRESA</th>
                            <th>CLICKS</th>
                            <th>ESTADO</th>

                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $empresas_no_published; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($empresa->empresa); ?></td>
                                <td><?php echo e($empresa->votos); ?></td>
                                <td>
                                    <?php if($empresa->publico): ?>
                                        Publicado
                                    <?php else: ?>
                                        No visible
                                    <?php endif; ?>

                                </td>
                                <td>
                                    <?php if(count($ordenes_verificadas)>0): ?>
                                        <?php if(!$empresa->publico): ?>
                                            <form action="<?php echo e(route('empresa_publicar')); ?>" class="d-inline formulario" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <input type="text" name="empresa_id" hidden value="<?php echo e($empresa->id); ?>">
                                                <button type="submit" class="btn btn-success" title="Publicar">
                                                    <i class="fa fa-fw fa-share text-white"></i> Publicar   
                                                </button>
                                            </form>  
                                        <?php else: ?>
                                            <a href="<?php echo e(route('empresa_mostrar', $empresa->id)); ?>" class="btn-accion-tabla tooltipsC" title="Ver esta empresa">
                                                <i class="fa fa-fw fa-eye text-primary"></i> Ver Empresa
                                            </a>

                                        <?php endif; ?>
                                    <?php else: ?>
                                        <?php if($empresa->publico): ?>
                                            <a href="<?php echo e(route('empresa_mostrar', $empresa->id)); ?>" class="btn-accion-tabla tooltipsC" title="Ver esta empresa">
                                                <i class="fa fa-fw fa-eye text-primary"></i> Ver Empresa
                                            </a>
                                        <?php else: ?>
                                            <a href="<?php echo e(route('pago_formas')); ?>" class="btn btn-danger"> Obtener Orden </a>
                                        <?php endif; ?>    
                                        
                                    <?php endif; ?>    
                                </td>
                            </tr>        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div> <!-- FIN ROW -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\foconsito\resources\views/orden/asignar.blade.php ENDPATH**/ ?>