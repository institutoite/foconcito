<a href="<?php echo e(route('empresa_editar', $id)); ?>" class="btn-accion-tabla tooltipsC" title="Editar esta empresa">
    <i class="fa fa-fw fa-edit text-primary"></i>
</a>

<a href="<?php echo e(route('empresa_mostrar', $id)); ?>" class="btn-accion-tabla tooltipsC" title="Ver esta empresa">
    <i class="fa fa-fw fa-eye text-primary"></i>
</a>

<a href="<?php echo e(route('empresa_compartir',$id)); ?>" class="btn-accion-tabla tooltipsC" title="Compartir Empresa">
    <i class="fab fa-whatsapp-square"></i>
</a>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('empresa_eliminar')): ?>
    <form action="<?php echo e(route('empresa_eliminar', $id)); ?>" id="form<?php echo e($id); ?>" class="d-inline formulario" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field("delete"); ?>
        <button name="btn-eliminar" id="<?php echo e($id); ?>" type="submit" class="btn eliminar" title="Eliminar esta empresa">
            <i class="fa fa-fw fa-trash text-danger"></i>   
        </button>
    </form>     
<?php endif; ?>    
<?php /**PATH C:\xampp\htdocs\foconsito\resources\views/empresa/acciones.blade.php ENDPATH**/ ?>