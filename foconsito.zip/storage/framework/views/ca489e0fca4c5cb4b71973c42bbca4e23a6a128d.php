
<?php $__env->startSection('css'); ?>
  
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap-fileinput/css/fileinput.min.css')); ?>">
                        
<?php $__env->stopSection(); ?>
<?php $__env->startSection("contenido"); ?>
    <div class="row mt-3 p-3 justify-content-center align-content-center"> 
        <div class="col-11 mb-3 fondo-azul" >
            <div class="row">
                <div class="col-12  text-center text-gray">
                    <strong> Agregar más productos o servicios </strong>   
                </div>
                </div>
            
                    <form action="<?php echo e(route('imagen_guardar')); ?>"  id="form-general" enctype="multipart/form-data" class="form-vertical mt-3" method="POST" autocomplete="on">
                        <?php echo csrf_field(); ?>
                        <?php echo $__env->make('producto.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    </form>
            </div>            
        </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('codigojs'); ?>
    <script src="<?php echo e(asset('lbgalery/js/gallery.js')); ?>"></script>
    
    <script src="<?php echo e(asset('bootstrap-fileinput/js/fileinput.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('bootstrap-fileinput/js/locales/es.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('bootstrap-fileinput/themes/fas/theme.min.js')); ?>" type="text/javascript"></script>
  
    <script>
        $('#imagenes').fileinput({
        language:'es',
        allowedFileExtensions:['jpg','jpeg','png'],
        maxFileSize:2000,
        showUpload:false,
        showClose:false,
        initialPreviewAsData:true,
        dropZoneEnabled:true,
        theme:"fas",
    });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\foconsito\resources\views/producto/crear.blade.php ENDPATH**/ ?>