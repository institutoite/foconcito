<?php $__env->startSection('titulo'); ?>
  Mostrar Persona
<?php $__env->stopSection(); ?>


<?php $__env->startSection('contenido'); ?>

   <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('empresa_listar')): ?>
        <div class="row">
            <div class="col-lg-12">  
                <div class="card-header border-success d-flex mt-3">
                    <h3 class="card-title">PERFIL DE: <strong> <?php echo e($persona->nombre.' '.$persona->apellidos); ?> </strong> </h3>
                    
                </div>
                <div class="card-body"> 
                    <table id="telofempresas" class="table table-hover table-bordered table-striped">
                        <thead class="bg-cyan">
                        
                            <th>#</th>
                            <th>Numero</th>
                            <th>Detalle</th>
                            <th>Actualizado</th>
                            <th>Contactar</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $telefonos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $telefono): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($telefono->numero); ?></td>
                                    <td><?php echo e($telefono->detalle); ?></td>
                                    <td><?php echo e($telefono->updated_at); ?></td>
                                    <td>
                                        <a class="btn btn-success btn-sm" href="https://api.whatsapp.com/send?phone=<?php echo e($telefono->prefijo.$telefono->numero); ?>" target="_blank"><i class="fab fa-whatsapp"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                
            </div>
        </div> <!-- FIN ROW -->
    <?php else: ?> 
        <?php echo $__env->make('includes.sinpermiso', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('persona_mostrar')): ?>
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body table-responsive">
                              <!-- Horizontal Form -->
                            <?php echo $__env->make('includes.form-error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo $__env->make('includes.mensaje', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>             
                        
                        
                           

                        

                            <h3 class="card-title text-center"><strong> DATOS PERSONALES </strong> </h3>
                            <div class="card-body">
                                
                                <table class="table table-bordered table-hover table-striped">
                                    <thead class="bg-cyan">
                                        <tr>
                                            <th>ATRIBUTO</th>
                                            <th>VALOR</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                       
                                        <tr>
                                            <td>NOMBRES</td>
                                            <td><?php echo e($persona->nombre); ?></td>
                                        </tr>
                                        <tr>
                                            <td>APELLIDOS</td>
                                            <td><?php echo e($persona->apellidos); ?></td>
                                        </tr>
                                        
                                        <tr>
                                            <td>FECHA NACIMIENTO</td>
                                            <td><?php echo e($persona->fechanacimiento->isoFormat('DD MMMM YYYY')); ?> <p class="text-gray"><?php echo e($persona->fechanacimiento->diffForHumans()); ?> </p> </td>
                                        </tr>
                                        <tr>
                                            <td>TIPO</td>
                                            <td><?php echo e($persona->tipo); ?></td>
                                        </tr>
                                        <tr>
                                            <td>PAIS</td>
                                            <td><?php echo e($persona->pais); ?></td>
                                        </tr>
                                        <tr>
                                            <td>CIUDAD</td>
                                            <td><?php echo e($persona->ciudad); ?></td>
                                        </tr>
                                        <tr>
                                            <td>ZONA</td>
                                            <td><?php echo e($persona->zona); ?></td>
                                        </tr>
                                        <tr>
                                            <td>CREADO</td>
                                            <td><?php echo e($persona->created_at); ?></td>

                                        </tr>
                                        <tr>
                                            <td>ACUALIZADO</td>
                                            <td><?php echo e($persona->updated_at); ?></td>
                                        </tr>
                                    </tbody>      
                                </table>
                            </div>
                        

                        </div>    
                    </div>
                </div>
            </div> <!-- FIN ROW -->
        </div>  
    <?php else: ?> 
        <?php echo $__env->make('includes.sinpermiso', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?> 


    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('codigojs'); ?>

<script src="https://cdn.datatables.net/responsive/2.2.4/js/dataTables.responsive.min.js"></script>
<script type="text/javascript">


$(document).ready(function() {

    $('#telofempresas').DataTable({ 
     
       
        
        "language":{
            "search":"Buscar",
            "paginate":{
                "next":"Siguiente",
                "previous":"Anterior",
            },
            "lengthMenu": 'Mostrar <select>' +
                                    '<option value="5">5</option>'+
                                    '<option value="10">10</option>'+
                                    '<option value="20">20</option>'+
                                    '<option value="50">50</option>'+
                                    '<option value="-1">Todos</option>'+
                                    '</select> Registros',
            "loadingsRecords":"Cargando....",
            "processing":"Procesando...",
            "emptyTable":"No encontre números telefónicos",
            "infoEmpty":"",
            "infoFiltered":"",
            "zeroRecords":"No hay datos",  
            "info": "Registro _START_ / _TOTAL_",
        }
    })

    $('table').on('click','.eliminar',function (e) {
        
        e.preventDefault();   
        Swal.fire({
            title: 'Estas seguro(a) de eliminar este registro?',
            text: "Si eliminas el registro no lo podras recuperar jamás!",
            icon: 'question',
            showCancelButton: true,
            showConfirmButton:true,
            confirmButtonColor: '#25ff80',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Eliminar..!',
            position:'center',        
        }).then((result) => {
            if (result.value) {
                var $form=$(this).parent();
                $form.append('<input name="_token" type="hidden" value="' + $('meta[name="csrf-token"]').attr('content') + '">');
                console.log('_token');
                $(this).parent().submit();
                Swal.fire(
                'Borrado Correctamente!',
                'El registro fue eliminado definitivamente.',
                'success')
            }else{
                const Toast = Swal.mixin({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 2000,
                    timerProgressBar: true,
                    onOpen: (toast) => {
                        toast.addEventListener('mouseenter', Swal.stopTimer)
                        toast.addEventListener('mouseleave', Swal.resumeTimer)
                    }
                })

                Toast.fire({
                    icon: 'error',
                    title: 'No se eliminó el registro'
                })
            }
        })
});


} );
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\foconsito\resources\views/persona/mostrar.blade.php ENDPATH**/ ?>