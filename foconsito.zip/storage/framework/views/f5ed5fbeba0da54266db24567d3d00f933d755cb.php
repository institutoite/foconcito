<?php $__env->startSection('titulo'); ?>
  Mostrar producto
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?> 
   

<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
    <div class="carousel-inner" role="listbox">
        <?php $__currentLoopData = $imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ima): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($loop->iteration==1): ?>
                <div class="carousel-item active">
            <?php else: ?>
                <div class="carousel-item">
            <?php endif; ?>
                <img class="rounded img-responsive center-block"  src="<?php echo e(isset($ima->foto) ? Storage::url($ima->foto) : Storage::url('galerias/sinimagenes.jpg')); ?>" alt="<?php echo e($producto->titulo); ?>" width="90%" height="450px">    
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
        <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        
        <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
        
    </div>
</div>
        <div class="container-fluid">
          

            <!-- DATOS DE PRODCUTO -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body table-responsive">
                                <!-- Horizontal Form -->
                            <?php echo $__env->make('includes.form-error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo $__env->make('includes.mensaje', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>             
                            
                            
                            <div class="card-header text-center"> 
                                <a  href="<?php echo e(route('imagen_contactar',$producto->id)); ?>" target="_blank" class="btn bg-success text-white col-4"><i class="fab fa-whatsapp text-white"> Contactar</i></a></td>
                            </div>        

                            <div class="card bg-transparent mb-3" style="max-width: 100%;">
                                <div class="card-header text-center"> DETALLE PRODUCTO</div>
                                <div class="card-body">
                                    
                                    <table class="table table-bordered table-hover table-striped" id="mensaje">
                                        <thead class="bg-cyan">
                                            <tr>
                                                <th>ATRIBUTO</th>
                                                <th>VALOR</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>ID</td>
                                                <td><?php echo e($producto->id); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Título</td>
                                                <td><?php echo e($producto->titulo); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Descripción</td>
                                                <td> 
                                                    <?php echo e($producto->descripcion); ?>

                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Costo</td>
                                                <td> 
                                                    <?php echo e($producto->costo); ?> Bs.
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>CREADO</td>
                                                <td><?php echo e($producto->created_at); ?></td>
                                            </tr>
                                            
                                        </tbody>      
                                    </table>
                                </div>
                            </div>
                        </div>    
                    </div>
                </div>
            </div> <!-- FIN ROW -->
        </div>  
       
<?php $__env->stopSection(); ?>

<?php $__env->startSection('codigojs'); ?>
    
    <script src="<?php echo e(asset("dist/js/alertas.js")); ?>"></script>

    <script type="text/javascript">
    $(document).ready(function(){
          
    });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\foconsito\resources\views/producto/mostrar.blade.php ENDPATH**/ ?>