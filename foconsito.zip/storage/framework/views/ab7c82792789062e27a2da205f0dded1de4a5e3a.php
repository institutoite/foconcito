<?php $__env->startSection('titulo'); ?>
  Editar Producto
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('bootstrap-fileinput/css/fileinput.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>  
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('imagen_actualizar')): ?>
        <div class="row">
            <div class="col-12">
                    <?php echo $__env->make('includes.form-error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('includes.mensaje', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>     
                    
                    <div class="card-header bg-cyan mt-3">
                            <h3 class="card-title">EDITAR PRODUCTO O SERVICIO</h3>
                    </div>
                    <div class="card-body"> 
                            

                        <form action="<?php echo e(route('imagen_actualizar',$imagen_a_editar->id)); ?>"  id="form-general" enctype="multipart/form-data" class="form-vertical mt-3" method="POST" autocomplete="on">
                            <?php echo csrf_field(); ?>
                            
                          
                              <div class="form-group">
                                <label for="detalle">Seleccione imagen del producto</label>
                                <input type="file" name="imagen[]" accept=".png, .jpg, .jpeg" id="imagenes" data-initial-preview="http://www.placehold.it/200x150/EFEFEF/AAAAAA&text=Agregar+Imagenes" multiple accept="image/*">                
                                
                            </div>
                                
                            <div class="form-group">
                                
                                <input  type="text" name="titulo" class="form-control" value="<?php echo e(old('titulo',$imagen_a_editar->titulo ?? '')); ?>" placeholder="Ingrese un título">
                                <small id="nombreHelp" class="form-text text-muted">Favor introduzca un títutlo del producto o servicio</small>    
                            </div>


                            <div class="form-group">
                                <textarea  name="descripcion" class="form-control" value="<?php echo e(old('descripcion',$imagen_a_editar->descripcion ?? '')); ?>" placeholder="Ingrese una descripcion del producto o servicio" rows="3"><?php echo e(old('descripcion',$imagen_a_editar->descripcion ?? '')); ?></textarea>
                                <small id="nombreHelp" class="form-text text-muted">Favor introduzca una descripcion del producto o servicio</small>    
                            </div>

                        
                            <div class="form-group">
                                <input  type="number" name="costo" class="form-control" value="<?php echo e(old('costo',$imagen_a_editar->costo ?? '')); ?>" placeholder="Ingrese un costo del producto o servicio">
                                <small id="nombreHelp" class="form-text text-muted">Favor introduzca el costo en Bs. del producto o servicio</small>    
                            </div>


                            <input type="text" hidden name="empresa_id" id="idempresa" value="<?php echo e($id); ?>">

                            <div class="text-center mb-2 mt-2">
                                <input type="submit" class="btn btn-success" value="Actualizar Producto Servicio">
                            </div>
                        </form>
                    </div> 
                </div>    
            </div>
    

            <?php if(count($imagenes)==0): ?>
                <div class="alert alert-success alert-dismissible" id="alert" data-auto-dismiss="1500">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <h5><i class="icon fas fa-check"></i> Mensaje Foconcito </h5>
                <div class="alert alert-success">
                    <ul>
                            <li><?php echo e("Ud. aun no tiene imagenes registrados para este producto"); ?></li>
                    </ul>
                </div>
                </div>
            <?php endif; ?>
               <?php
                   $i=1;
               ?> 

             <div id="gallery">
                
                <?php $__currentLoopData = $imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ima): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if((($i-1) % 4==0)||($i==1)): ?>
                        <div class="row">
                            <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 input-group mb-3" >
                                <div class="card text-white mb-3 borde-cyan" style="max-width: 36rem;">
            
                                        <div class="card-body">
                                                <img class="img-thumbnail zoomify" src="<?php echo e(isset($ima->foto) ? Storage::url($ima->foto) : Storage::url('galerias/sinimagenes.jpg')); ?>" alt="">
                                        </div>
                                        <div class="text-center">
                                            <form action="<?php echo e(route('imagen_delete', $ima->id)); ?>" id="form<?php echo e($ima->id); ?>" class="d-inline formulario" method="POST">
                                            <?php echo csrf_field(); ?>
                                                <?php echo method_field("delete"); ?>
                                                <button name="btn-eliminar" id="<?php echo e($ima->id); ?>" type="submit" class="btn" title="Eliminar esta imagen"><i class="fa fa-fw fa-trash text-danger"></i>   
                                                </button>
                                            </form>
                                        </div>
                                </div>
                                
                            </div>                            
                    <?php else: ?>    
                        <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 input-group mb-3" >
                                <div class="card text-white mb-3" style="max-width: 36rem;">
                                
                                        <div class="card-body">
                                                <img class="img-thumbnail zoomify" src="<?php echo e(isset($ima->foto) ? Storage::url($ima->foto) : Storage::url('galerias/sinimagenes.jpg')); ?>" alt="">
                                        </div>
                                        <div class="text-center">
                                            <form action="<?php echo e(route('imagen_delete', $ima->id)); ?>" id="form<?php echo e($ima->id); ?>" class="d-inline formulario" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field("delete"); ?>
                                                <button name="btn-eliminar" id="<?php echo e($ima->id); ?>" type="submit" class="btn" title="Eliminar esta imagen"><i class="fa fa-fw fa-trash text-danger"></i>   
                                            </button>
                                        </form>
                                        </div>
                                        
                                        
                                </div>
                            </div> 
                        <?php if(($i) % 4 == 0): ?>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php
                        $i=$i+1;    
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    
    <?php else: ?> 
        <?php echo $__env->make('includes.sinpermiso', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?> 

    

    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('codigojs'); ?>
<script src="<?php echo e(asset('lbgalery/js/gallery.js')); ?>"></script>
<script src="<?php echo e(asset('bootstrap-fileinput/js/fileinput.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('bootstrap-fileinput/js/locales/es.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('bootstrap-fileinput/themes/fas/theme.min.js')); ?>" type="text/javascript"></script>

    

<script>
  
    $('#imagenes').fileinput({
        language:'es',
        //showCaption: true,
        allowedFileExtensions:['jpg','jpeg','png'],
        maxFileSize:4000,
        showUpload:true,
        showClose:false,
        initialPreviewAsData:true,
        
        dropZoneEnabled:false,
        theme:"fas",
    });
   
    
</script>    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\foconsito\resources\views/galeria/editar.blade.php ENDPATH**/ ?>