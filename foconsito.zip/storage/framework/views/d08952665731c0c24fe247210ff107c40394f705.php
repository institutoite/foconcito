<?php $__env->startSection('titulo'); ?>
  Editar Mensaje
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/emojionearea/3.4.2/emojionearea.min.css">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>     
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('mensaje_actualizar')): ?>
            <div class="row">
                <div class="col-12">
                    <?php echo $__env->make('includes.form-error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('includes.mensaje', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>     
                  
                        <div class="card-header bg-cyan mt-3">
                            <h3 class="card-title">FORMULARIO EDITAR MENSAJE</h3>
                        </div>
                        <div class="card-body borde-cyan"> 
                            
                            <form action="<?php echo e(route('mensaje_actualizar',['id'=>$mensaje_a_editar->id])); ?>"  id="form-general form-editar" class="form-vertical form-" method="POST" autocomplete="on">
                                <?php echo csrf_field(); ?>
                                    <?php echo $__env->make('mensaje.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php echo $__env->make('includes.boton_actualizar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </form>
                        </div> 
            
                </div>    
            </div>
    <?php else: ?> 
        <?php echo $__env->make('includes.sinpermiso', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('codigojs'); ?>
  
<script src="https://cdnjs.cloudflare.com/ajax/libs/emojionearea/3.4.2/emojionearea.js"></script>

<script type="text/javascript">
 
    $(document).ready(function(){
        $(".emojionearea").emojioneArea({
            pickerPosition:"bottom",
            buttonTitle: "Favor click aquí para agregar emojis a tu mensaje",
        });

    });	
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\foconsito\resources\views/mensaje/editar.blade.php ENDPATH**/ ?>