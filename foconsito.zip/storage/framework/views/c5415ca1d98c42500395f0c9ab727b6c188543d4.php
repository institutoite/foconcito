

<div class="row">
    <div class="col-12 input-group mb-2" >
        <select class="form-control" name="pais_id" id="country">
            <option value=""> Elija una país</option>
            <?php $__currentLoopData = $paises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pais): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(isset($zona_a_editar)): ?>     
                    <option  value="<?php echo e($pais->id); ?>" <?php echo e($pais->id==$zona_a_editar->pais_id ? 'selected':''); ?>><?php echo e($pais->pais); ?></option>     
                <?php else: ?>
                    <option value="<?php echo e($pais->id); ?>" <?php echo e(old('pais_id') == $pais->id ? 'selected':''); ?> ><?php echo e($pais->pais); ?></option>
                <?php endif; ?> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</div>
 

<div class="row"> 
    <div class="input-group mb-3 col-12" >
        
        <select class="form-control" name="ciudad_id" id="city">
            <option value=""> Elija una ciudad</option>
            <?php $__currentLoopData = $ciudades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(isset($zona_a_editar)): ?>     
                    <option value="<?php echo e($item->id); ?>" <?php echo e($item->id==$zona_a_editar->ciudad_id ? 'selected':''); ?> ><?php echo e($item->ciudad); ?></option>
                
                <?php endif; ?> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
         <a href="<?php echo e(route('ciudad_crear')); ?>"> <i class="fas fa-plus-circle text-success fa-2x"></i> </a>
    </div>
</div>

<div class="row"> 
    <div class="input-group mb-3 col-12" >
        <input  type="text" name="zona" id="zona" class="form-control" style="position:relative" value="<?php echo e(old('zona',$zona_a_editar->zona ?? '')); ?>" placeholder="ingrese una zona" autocomplete="off">
        <div id="listazonas"></div>
    </div>
    
</div>


<?php /**PATH C:\xampp\htdocs\foconsito\resources\views/zona/form.blade.php ENDPATH**/ ?>