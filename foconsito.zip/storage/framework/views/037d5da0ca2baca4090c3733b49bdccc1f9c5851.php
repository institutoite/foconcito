
<?php if(session('mensaje')): ?>
    <div class="alert bg-success alert-dismissible" id="alert" data-auto-dismiss="1500">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        <h5><i class="icon fas fa-check"></i> Mensaje Foconcito </h5>
            <div class="alert alert-success">
                <ul>
                        <li><?php echo e(session('mensaje')); ?></li>
                </ul>
            </div>
    </div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\foconsito\resources\views/includes/mensaje.blade.php ENDPATH**/ ?>