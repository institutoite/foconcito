<?php $__env->startSection('titulo'); ?>
  Mostrar Pago
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>     
  
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                
                   
                              <!-- Horizontal Form -->
                        <?php echo $__env->make('includes.form-error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php echo $__env->make('includes.mensaje', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>             
                        
                      
                            <?php
                                if($pago[0]->monto>0){
                                    $clase="badge-success";    
                                }else{
                                    $clase="badge-danger";   
                                }
                               
                            ?>
                            
                            <ul class="list-group mt-3">
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    CODIGOPAGO: 
                                    <span class="badge <?php echo e($clase); ?> badge-pill"><?php echo e($pago[0]->id); ?></span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    EMPRESARIO: 
                                    <span class="badge <?php echo e($clase); ?> badge-pill"><?php echo e($pago[0]->nombre); ?></span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    FECHAHORA:
                                    <span class="badge <?php echo e($clase); ?> badge-pill"><?php echo e($pago[0]->created_at); ?></span>
                                </li>

                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    METODO PAGO : <?php echo e($pago[0]->metodo); ?>

                                    <span class="badge <?php echo e($clase); ?> badge-pill">Bs. <?php echo e($pago[0]->monto); ?></span>
                                </li>
                            </ul>

                            
                            <div class="card-body">
                                
                                <form action="<?php echo e(route('pago_verificar')); ?>" id="form-general" class="form-vertical form-" method="POST" autocomplete="on">
                                <?php echo csrf_field(); ?>
                                <input type="number" name="id" value="<?php echo e($pago[0]->id); ?>" id="" hidden>
                                <input type="number" name="monto" class="form-control" value="<?php echo e($costo); ?>" placeholder="Favor introduza cuanto pago">
                                <input type="submit" class="btn btn-success" value="Validar">    
                            </form>
                            </div>    

                            

                            <div>
                                <img src="<?php echo e(Storage::url($pago[0]->comprobante)); ?>" alt="Comprobante" width="100%">
                            </div>
                        
            </div>
        </div> <!-- FIN ROW -->
    </div>
   
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\foconsito\resources\views/pago/mostrar.blade.php ENDPATH**/ ?>