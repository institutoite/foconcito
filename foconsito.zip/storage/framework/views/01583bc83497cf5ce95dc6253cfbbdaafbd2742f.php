
<?php $__env->startSection('titulo'); ?>
  Crear Contacto
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
     <link rel="stylesheet" href="<?php echo e(asset("dist/css/custom.css")); ?>">
     <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.4/css/responsive.dataTables.min.css">
     <link rel="stylesheet" href="https://cdn.datatables.net/1.10.23/css/dataTables.bootstrap4.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>           
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('persona_crear')): ?>
        <div class="row">
            <div class="col-lg-12">  
                <div class="card-header border-success d-flex mt-3">
                    <h3 class="card-title"><strong>Enviar Mensaje:</strong>  <?php echo e($mensaje->mensaje); ?> </h3>
                </div>
                
                <div class="card-body"> 
                    <table id="clientes" class="table table-striped table-bordered table-hover table-condensed">
                        <thead>
                            <tr>
                                <th>Nombre</th>
                                <th>apellidos</th>
                                <th>Número</th>
                                <th>Opciones</th>
                            </tr>
                        </thead>
                        <tbody>
                                <?php $__currentLoopData = $telefonos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $telefono): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($telefono->nombre); ?> </td>
                                        <td><?php echo e($telefono->apellidos); ?> </td>
                                        <td><?php echo e($telefono->numero); ?> </td>
                                        <td>
                                            <?php
                                                $link="https://api.whatsapp.com/send?phone=+".$telefono->prefijo.$telefono->numero."&text=". str_replace(" ","%20",$mensaje->mensaje);    
                                            ?>
                                            
                                            
                                            <a href="<?php echo e($link); ?>" target="_blank" class="btn-accion-tabla tooltipsC" title="Compartir tu empresa con este cliente">
                                                <i class="fas fa-share-alt-square text-success fa-2x"></i>
                                            </a>
                                             
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div> <!-- FIN ROW -->
    <?php else: ?> 
        <?php echo $__env->make('includes.sinpermiso', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('codigojs'); ?>
<script src="https://cdn.datatables.net/responsive/2.2.4/js/dataTables.responsive.min.js"></script>
<script src="https://cdn.datatables.net/1.10.23/js/dataTables.bootstrap4.min.js"></script>
<script type="text/javascript">
$(document).ready(function() {

    $('#clientes').DataTable({ 
        
       
            "responsive":true,
            "language":{
            "search":"Buscar",
            "paginate":{
                "next":"Siguiente",
                "previous":"Anterior",
            },
            "lengthMenu": 'Mostrar <select>' +
                                    '<option value="5">5</option>'+
                                    '<option value="10">10</option>'+
                                    '<option value="20">20</option>'+
                                    '<option value="50">50</option>'+
                                    '<option value="-1">Todos</option>'+
                                    '</select> Registros',
            "loadingsRecords":"Cargando....",
            "processing":"Procesando...",
            "emptyTable":"Sin elementos",
            "infoEmpty":"",
            "infoFiltered":"",
            "zeroRecords":"No hay datos",  
            "info": "Registros del _START_ al _END_ de _TOTAL_ registros",
        }
    })
    } );
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\foconsito\resources\views/mensaje/enviar.blade.php ENDPATH**/ ?>