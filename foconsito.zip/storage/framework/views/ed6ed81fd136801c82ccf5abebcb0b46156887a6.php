<?php $__env->startSection('titulo'); ?>
  Config
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>     
    
    
        <div class="row mt-4">
            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2 input-group mb-2" >
            </div>    
            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3 input-group mb-2" >
                <div class="card">
                  
                    <div class="card-body">
                        <h4 class="card-title text-center">Agregar mas números telefónicos</h4>
                            <a href="<?php echo e(route('telofempresa_crear',$id_empresa)); ?>">        
                                <img class="img-thumbnail" src="/imagenes/mastelefonos.png" alt="">
                                <div class="text-center">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2 input-group mb-2" >
            </div>   
            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3 input-group mb-2" >
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title text-center">Agregar mas productos o servicios</h4>
                            <a href="<?php echo e(route('empresa_galeria', $id_empresa)); ?>">        
                                <img class="img-thumbnail" src="/imagenes/masproductos.png" alt="">
                                <div class="text-center">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-2 input-group mb-2" >
            </div>   
        </div>   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\foconsito\resources\views/empresa/numero_producto.blade.php ENDPATH**/ ?>