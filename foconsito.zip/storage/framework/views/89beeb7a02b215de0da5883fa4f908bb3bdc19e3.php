
<a href="<?php echo e(route('mensaje_editar', $id)); ?>" class="btn-accion-tabla tooltipsC mr-2" title="Editar esta Mensaje">
    <i class="fa fa-fw fa-edit text-primary"></i>
</a>

<a href="<?php echo e(route('mensaje_mostrar', $id)); ?>" class="btn-accion-tabla tooltipsC mr-2" title="Ver esta Mensaje">
    <i class="fa fa-fw fa-eye text-primary"></i>
</a>

<a href="<?php echo e(route('bombardear',$id)); ?>" class="btn-accion-tabla tooltipsC" title="Compartir tu empresa con este cliente">
    <i class="fas fa-share-alt-square text-success"></i>
</a> 


<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('mensaje_eliminar')): ?>
    <form action="<?php echo e(route('mensaje_eliminar', $id)); ?>" id="form<?php echo e($id); ?>" class="d-inline formulario" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field("delete"); ?>
        <button name="btn-eliminar" id="<?php echo e($id); ?>" type="submit" class="btn eliminar" title="Eliminar esta Mensaje">
            <i class="fa fa-fw fa-trash text-danger"></i>   
        </button>
    </form> 
<?php endif; ?>
    <?php /**PATH C:\xampp\htdocs\foconsito\resources\views/mensaje/acciones.blade.php ENDPATH**/ ?>