<?php $__env->startSection('titulo'); ?>
  Galería
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('lbgalery/css/gallery.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("dist/css/custom.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap-fileinput/css/fileinput.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("zoomify/zoomify.css")); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>   

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('empresa_galeria')): ?>
        <?php echo $__env->make('includes.form-error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('includes.mensaje', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    
       
        <?php if(count($imagenes)==0): ?>
            <div class="alert alert-success alert-dismissible" id="alert" data-auto-dismiss="1500">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <h5><i class="icon fas fa-check"></i> Mensaje Foconcito </h5>
                <div class="alert alert-success">
                    <ul>
                            <li><?php echo e("Ud. aun no tiene productos registradas en Foconcito"); ?></li>
                    </ul>
                </div>
        </div>
        <?php endif; ?>

        <?php
            $i=1; // variable para crear un nuevo row o añadir a contunuacion de 4 en 4
        ?>

        <div class="row mb-3">

        </div>

        <div id="gallery">
                
                <?php $__currentLoopData = $imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ima): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if((($i-1) % 4==0)||($i==1)): ?>
                        <div class="row">
                            <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 input-group mb-3" >
                                <div class="card text-white mb-3 borde-cyan" style="max-width: 36rem;">
                                    <div class="card-header bg-cyan text-center"><?php echo e($ima->titulo); ?></div>
                                        <div class="card-body">
                                                <img class="img-thumbnail zoomify" src="<?php echo e(isset($ima->foto) ? Storage::url($ima->foto) : Storage::url('galerias/sinimagenes.jpg')); ?>" alt="">
                                        </div>
                                        <div class="text-center botonaccion">
                                            <p class="text-gray"> <?php echo e($ima->descripcion); ?></p>
                                        </div>
                                        <?php echo $__env->make('empresa.accionesgaleria', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                                
                            </div>                            
                    <?php else: ?>    
                        <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 input-group mb-3" >
                                <div class="card text-white mb-3" style="max-width: 36rem;">
                                    <div class="card-header bg-cyan borde-cyan text-center"><?php echo e($ima->titulo); ?></div>
                                        <div class="card-body">
                                                <img class="img-thumbnail zoomify" src="<?php echo e(isset($ima->foto) ? Storage::url($ima->foto) : Storage::url('galerias/sinimagenes.jpg')); ?>" alt="">
                                        </div>
                                        <div class="text-center botonaccion">
                                            <p class="text-gray"> <?php echo e($ima->descripcion); ?></p>
                                        </div>
                                        <?php echo $__env->make('empresa.accionesgaleria', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
                                </div>
                            </div> 
                        <?php if(($i) % 4 == 0): ?>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php
                        $i=$i+1;    
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="row">
            <div class="card">
                <a href="<?php echo e(route('imagen_crear',15)); ?>" class="btn btn-success"><i class="fas fa-plus-square"></i> Agregar Productos</a>
            </div>
        </div>
    <?php else: ?> 
        <?php echo $__env->make('includes.sinpermiso', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('codigojs'); ?>
<script src="<?php echo e(asset('lbgalery/js/gallery.js')); ?>"></script>
<script src="<?php echo e(asset('bootstrap-fileinput/js/fileinput.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('bootstrap-fileinput/js/locales/es.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('bootstrap-fileinput/themes/fas/theme.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('zoomify/zoomify.js')); ?>" type="text/javascript"></script>
    

<script>
    $('.zoomify').zoomify();
    $('#imagenes').fileinput({
        language:'es',
        allowedFileExtensions:['jpg','jpeg','png'],
        showUpload:false,
        maxFileSize: 25000,
        maxFileCount: 10,
        showClose:false,
        uploadUrl: "/site/test-upload",
        enableResumableUpload: true,
        initialPreviewAsData:true,
        dropZoneEnabled:true,
        showRemove: true,
        deleteUrl: '/site/file-delete',
    
        theme:"fas",
    });
   
    
</script>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\foconsito\resources\views/empresa/galeria.blade.php ENDPATH**/ ?>