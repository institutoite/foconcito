<?php $__env->startSection('titulo'); ?>
  Crear Zona
<?php $__env->stopSection(); ?>


<?php $__env->startSection('contenido'); ?> 
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('zona_crear')): ?>    
    <div class="row">
        <div class="col-lg-12">
            
                <?php echo $__env->make('includes.form-error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('includes.mensaje', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>             
                
                        <div class="card-header bg-cyan mt-3">
                        <h3 class="card-title">FORMULARIO ZONA </h3> <a class="btn btn-danger float-right" href="<?php echo e(route('empresa_crear')); ?>">Crear Empresa</a>
                        </div>
                            <form action="<?php echo e(route('zona_guardar')); ?>"  id="form-general" class="form-vertical form-" method="POST" autocomplete="on">
                                <?php echo csrf_field(); ?>
                                <div class="card-body"> 
                                    <?php echo $__env->make('zona.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>    
                                <div class="card-footer">   
                                    <?php echo $__env->make('includes.boton_crear', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </form>  
        </div>
    </div>
 <?php else: ?> 
    <?php echo $__env->make('includes.sinpermiso', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('codigojs'); ?>


<script>
    $(document).ready(function(){
        $('#country').on('change', cargarciudades);  
    });	
       function cargarciudades(){
        var country_id = $(this).val();
        console.log(country_id);
        if(!country_id){
            $('#city').html('<option value="">Seleccione una Ciudad </option>');
        return;
        }
        $.get('/api/pais/'+ country_id +'/ciudades',function (data) {
            var html_select='<option value="">Seleccione una Ciudad </option>';
            for (var i = 0; i < data.length; i++) {
                html_select+='<option value="'+ data[i].id +'">' +data[i].ciudad +'</option>';
                //console.log(html_select);
            }
            $('#city').html(html_select);
        });
    }
</script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\foconsito\resources\views/zona/crear.blade.php ENDPATH**/ ?>