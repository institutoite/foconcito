<?php $__env->startSection('titulo'); ?>
  Buscar empresas
<?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>
  <link rel="stylesheet" href="<?php echo e(asset("dist/css/custom.css")); ?>">  
<?php $__env->stopSection(); ?>



<?php $__env->startSection('contenido'); ?>

<div class="row">
    <div class="col">
        <p class="text-muted">  <?php echo e($mensaje ?? 'Que estas buscando?'); ?> <a class="float-right text-primary" href="<?php echo e(route('busqueda_avanzada')); ?>">Búsqueda por zona </a></p>  
    </div>
</div> 

<div class="row">
    <img src="" alt="">
</div>

<img src="<?php echo e(asset("imagenes/buscador.png")); ?>" width="300" alt="">
    <!--h1 class="display-6 text-center text-gray col-sm">Lo que buscas está a un Click</h1-->
    <div class="row">
        <form class="form-horizontal col-12" method="get" action="<?php echo e(route('empresa_buscar')); ?>">
             
             
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 input-group mb-2 p-2">
                    
                    <input class="form-control" type="text" required value="<?php echo e(old('criterio',$criterio ?? '')); ?>" name="criterio" id="criterio" placeholder="Escribe aquí que Busca Ej. Celulares, Ropa, Casa etc"
                    aria-label="Search">
                    <button type="submit" class="btn btn-success btn-sm" id="submit">Buscar <i class="fas fa-search text-white-50" aria-hidden="true"></i> </button>
                </div>
        </form>
    </div>

    <?php if(session('mensaje')): ?>
    <div class="alert bg-success alert-dismissible" id="alert" data-auto-dismiss="1500">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        <h5><i class="icon fas fa-check"></i> Mensaje Foconcito </h5>
            <div class="alert alert-success">
                <ul>
                        <li><?php echo e(session('mensaje')); ?></li>
                </ul>
            </div>
    </div>
<?php endif; ?>

    <?php if(isset($empresas)): ?>

   
        <?php
            $i=1;
        ?>   

        <div class="container">
                    <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if((($i-1) % 4==0)||($i==1)): ?>
                            <div class="row">
                                    <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 input-group mb-3" >
                                        <div class="card text-white mb-3 borde-cyan" style="max-width: 36rem;">
                                            <div class="card-header bg-cyan text-center"><?php echo e($empresa->empresa); ?></div>
                                                <div class="card-body">
                                                    <a href="<?php echo e(route('empresa_votar',$empresa->id)); ?>" target="_blank" class="titulo">
                                                        <img class="img-thumbnail zoomify" src="<?php echo e(isset($empresa->logo) ? Storage::url($empresa->logo) : Storage::url('galerias/sinimagenes.jpg')); ?>" alt="">
                                                    </a>    
                                                </div>
                                                <div class="text-center botonaccion">
                                                    <p class="text-gray cuerpo"> <?php echo e($empresa->detalle); ?></p>
                                                </div>
                                               <div class="row">
                                                    <div class="col-3">
                                                    </div>
                                                    <a href="<?php echo e(route('empresa_votar',$empresa->id)); ?>" class="btn btn-sm col-2"><i class="far fa-eye fa-2x text-info"></i></i></a>
                                                    <div class="col-2"></div>
                                                    <a  href="<?php echo e(route('empresa_votar',$empresa->id)); ?>" target="_blank" class="btn btn-sm col-2"><i class="fab fa-whatsapp text-success fa-2x"></i></i></a>
                                                    <div class="col-3">
                                                    </div>
                                                </div>

                                                <small id="nombreHelp" class="form-text text-muted"><?php echo e($empresa->ciudad."|".$empresa->zona."|".$empresa->direccion); ?></small>
                                        </div>
                                    </div>
                                
                    <?php else: ?>    
                            
                                <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 input-group mb-3" >
                                    <div class="card text-white mb-3" style="max-width: 36rem;">
                                        <div class="card-header bg-cyan borde-cyan text-center"><?php echo e($empresa->empresa); ?></div>
                                            <div class="card-body">
                                                    <a href="<?php echo e(route('empresa_votar',$empresa->id)); ?>" target="_blank" class="titulo">
                                                    <img class="img-thumbnail zoomify" src="<?php echo e(isset($empresa->logo) ? Storage::url($empresa->logo) : Storage::url('galerias/sinimagenes.jpg')); ?>" alt="">
                                                    </a>
                                            </div>
                                            <div class="text-center botonaccion">
                                                <p class="text-gray cuerpo"> <?php echo e($empresa->detalle); ?></p>
                                            </div>
                                            <div class="row">
                                                    <div class="col-3">
                                                    </div>
                                                    <a href="<?php echo e(route('empresa_votar',$empresa->id)); ?>" class="btn btn-sm col-2"><i class="far fa-eye fa-2x text-info"></i></i></a>
                                                    <div class="col-2"></div>
                                                    <a  href="<?php echo e(route('empresa_votar',$empresa->id)); ?>" target="_blank" class="btn btn-sm col-2"><i class="fab fa-whatsapp text-success fa-2x"></i></i></a>
                                                    <div class="col-3">
                                                    </div>
                                                </div>
                                            <small id="nombreHelp" class="form-text text-muted"><?php echo e($empresa->ciudad."|".$empresa->zona."|".$empresa->direccion); ?></small>  
                                    </div>
                                </div> 
                        <?php if(($i) % 4 == 0): ?>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php
                        $i=$i+1;    
                    ?>                  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
          
        </div> 
        <?php echo e($empresas->render()); ?>

    <?php endif; ?>
    

    <?php if(isset($productos)): ?>
    
        <?php
            $i=1;
        ?>
      
         <div class="container">
           
                    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if((($i-1) % 4==0)||($i==1)): ?>
                            <div class="row">
                                
                                    <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 input-group mb-3" >
                                        <div class="card text-white mb-3 borde-oscuro" style="max-width: 36rem;">
                                            <div class="card-header fondo text-center"><?php echo e($producto->titulo); ?></div>
                                                <div class="card-body producto">
                                                    <div class="precio text-center text-white">
                                                            <div class="textoprecio"> Bs. <?php echo e($producto->costo); ?> </div> 
                                                    </div>
                                                    
                                                    <img class="img-thumbnail zoomify" src="<?php echo e(isset($producto->foto) ? Storage::url($producto->foto) : Storage::url('galerias/sinimagenes.jpg')); ?>" alt="<?php echo e($producto->titulo); ?>">
                                                     
                                                </div>
                                                <div class="text-center botonaccion">
                                                    <p class="text-gray cuerpo"> <?php echo e($producto->descripcion); ?></p>
                                                </div>


                                    
                                            <div class="row">
                                                <div class="col-6">
                                                    <div class="row justify-content-center align-content-center">
                                                        <a href="<?php echo e(route('imagen_votar',$producto->id)); ?>" class="btn bg-info btn-sm text-white"><i class="far fa-eye text-white"> Ver </i></a>
                                                    </div>
                                                </div>
                                                <div class="col-6">
                                                    <div class="row justify-content-center align-content-center">
                                                        <a  href="<?php echo e(route('imagen_contactar',$producto->id)); ?>" target="_blank" class="btn bg-success text-white btn-sm"><i class="fab fa-whatsapp text-white"> Contactar</i></a>
                                                    </div>
                                                </div>
                                            </div>


                                                <small id="nombreHelp" class="form-text text-muted"><?php echo e($producto->created_at->diffForHumans().' en '.$producto->ciudad."|".$producto->zona."|".$producto->direccion); ?></small>
                                        </div>
                                    </div>
                                
                    <?php else: ?>    
                            
                                <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 input-group mb-3" >
                                    <div class="card text-white mb-3 borde-oscuro" style="max-width: 36rem;">
                                        <div class="card-header fondo borde-cyan text-center"><?php echo e($producto->titulo); ?></div>
                                            <div class="card-body producto">
                                                    <div class="precio text-center text-white">
                                                            <div class="textoprecio"> Bs. <?php echo e($producto->costo); ?> </div> 
                                                    </div>
                                                    
                                                    <img class="img-thumbnail zoomify" src="<?php echo e(isset($producto->foto) ? Storage::url($producto->foto) : Storage::url('galerias/sinimagenes.jpg')); ?>" alt="">
                                                    </a>
                                            </div>
                                            <div class="text-center botonaccion">
                                                <p class="text-gray cuerpo"> <?php echo e($producto->descripcion); ?></p>
                                            </div>
                                            
                                                <div class="row">
                                                <div class="col-6">
                                                    <div class="row justify-content-center align-content-center">
                                                        <a href="<?php echo e(route('imagen_votar',$producto->id)); ?>" class="btn bg-info btn-sm text-white"><i class="far fa-eye text-white"> Ver </i></a>
                                                    </div>
                                                </div>
                                                <div class="col-6">
                                                    <div class="row justify-content-center align-content-center">
                                                        <a  href="<?php echo e(route('imagen_contactar',$producto->id)); ?>" target="_blank" class="btn bg-success text-white btn-sm"><i class="fab fa-whatsapp text-white"> Contactar</i></a>
                                                    </div>
                                                </div>
                                            </div>
                                              

                                            <small id="nombreHelp" class="form-text text-muted"><?php echo e($producto->created_at->diffForHumans().' en '.$producto->ciudad."|".$producto->zona."|".$producto->direccion); ?></small>
                                            
                                    </div>
                                </div> 
                                
                        <?php if(($i) % 4 == 0): ?>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php
                        $i=$i+1;    
                    ?>                  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
           
        </div> 
        <?php echo e($productos->appends(['criterio' => $criterio])->links()); ?> 
    <?php endif; ?>
    
   
     
<?php $__env->stopSection(); ?>

<?php $__env->startSection('codigojs'); ?>
    <script type="text/javascript">
        $(document).ready(function(){
                $(".cuerpo").each(function(){
                    $(this).html($(this).text().substring(0,50)+"...");
                });
        });    
    </script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\foconsito\resources\views/errors/404.blade.php ENDPATH**/ ?>