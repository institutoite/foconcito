<?php if($errors->any()): ?>
    <div class="alert alert-danger alert-dismissible" id="alert" data-auto-dismiss="4000">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        <h5><i class="icon fas fa-ban"></i> Hay errores!</h5>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><i class="fas fa-times"></i><?php echo e($error); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
    </div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\foconsito\resources\views/includes/form-error.blade.php ENDPATH**/ ?>