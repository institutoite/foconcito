<div class="form-group">
    <label for="detalle">Pais</label>    
    <select name="prefijo" id="" class="form-control" >
                    <?php $__currentLoopData = $prefijos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prefijo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                        <?php if(isset($tel_a_editar)): ?>
                            <?php if($prefijo->prefijo==$tel_a_editar): ?>
                                <option value="<?php echo e($prefijo->prefijo); ?>" selected><?php echo e($prefijo->prefijo.'('.$prefijo->pais.')'); ?> </option>    
                            <?php else: ?>
                                <option value="<?php echo e($prefijo->prefijo); ?>"><?php echo e($prefijo->prefijo.'('.$prefijo->pais.')'); ?> </option>    
                            <?php endif; ?>
                        <?php else: ?>    
                            <option value="<?php echo e($prefijo->prefijo); ?>"><?php echo e($prefijo->prefijo.'('.$prefijo->pais.')'); ?> </option>    
                        <?php endif; ?> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                    					
                </select>
    <small id="nombreHelp" class="form-text text-muted">Favor seleccione prefijo de su pais.</small>
</div>

 <div class="form-group">
    <label for="detalle">Número</label>
    <input  type="number" name="numero" class="form-control" value="<?php echo e(old('numero',$tel_a_editar->numero ?? '')); ?>" placeholder="Número de teléfono">
    <small id="nombreHelp" class="form-text text-muted">Favor introduzca su numero telefonico.</small>
</div>

<div class="form-group">
    <label for="detalle">Detalle</label>
    <input  type="text" name="detalle" class="form-control" value="<?php echo e(old('detalle',$tel_a_editar->detalle ?? '')); ?>" placeholder="Detalle de telefono"> 
    <small id="nombreHelp" class="form-text text-muted">Favor introduzca un detalle</small>    
</div>

<input type="text" name="persona_id" hidden value="<?php echo e($id); ?>">
<?php /**PATH C:\xampp\htdocs\foconsito\resources\views/telefono/form.blade.php ENDPATH**/ ?>