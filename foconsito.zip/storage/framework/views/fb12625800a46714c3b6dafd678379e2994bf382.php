<?php $__env->startSection('titulo'); ?>
  Mostrar Empresa
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>     
    
        <div class="container-fluid">
            <div class="row d-flex">
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 mb-3 mx-auto" >
                    <div class="card text-white mb-3" style="max-width: 36rem;">
                        <div class="card-header bg-cyan text-center">EMPRESA: <?php echo e($empresita[0]->empresa); ?></div>
                            <div class="card-body">
                                <img class="img-thumbnail" src="<?php echo e(isset($empresita[0]->logo) ? Storage::url('/'.$empresita[0]->logo) : Storage::url('logos/sinlogo.png')); ?>" alt="">
                            </div>
                            <div class="text-center text-gray">
                                <p> Logotipo </p>
                            </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                
                        <?php if(count($imagenes)==0): ?>
                            <div class="alert alert-success alert-dismissible" id="alert" data-auto-dismiss="1500">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                    <h5><i class="icon fas fa-check"></i> Mensaje Foconcito </h5>
                                    <div class="alert alert-success">
                                    <ul>
                                            <li>Aun no tienes imagenes</li>
                                    </ul>
                                </div>
                            </div>
                        <?php endif; ?>
                              <!-- Horizontal Form -->
                        <?php echo $__env->make('includes.form-error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php echo $__env->make('includes.mensaje', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>             
                          
                        <div class="card bg-transparent mb-3" style="max-width: 100%;">           
                            <table class="table table-bordered table-hover table-striped">
                                <thead class="bg-cyan">
                                    <tr>
                                        <th>ATRIBUTO</th>
                                        <th>VALOR</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>ID</td>
                                        <td><?php echo e($empresita[0]->id); ?></td>
                                    </tr>
                                    <tr>
                                        <td>REPRESENTANTE</td>
                                        <td>
                                            <a href="<?php echo e(route('persona_mostrar', $empresita[0]->persona_id)); ?>"><?php echo e($empresita[0]->empresario); ?></a> 
                                            <a href="<?php echo e(route('persona_mostrar', $empresita[0]->persona_id)); ?>" class="btn btn-success">Contactar</a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>PAIS</td>
                                        <td><?php echo e($empresita[0]->pais); ?></td>
                                    </tr>
                                    <tr>
                                        <td>CIUDAD</td>
                                        <td><?php echo e($empresita[0]->ciudad); ?></td>
                                    </tr>
                                    <tr>
                                        <td>ZONA</td>
                                        <td><?php echo e($empresita[0]->zona); ?></td>
                                    </tr>
                                    <tr>
                                        <td>DIRECCION</td>
                                        <td><?php echo e($empresita[0]->direccion); ?></td>
                                    </tr>
                                    <tr>
                                        <td>DETALLE</td>
                                        <td> 
                                            <?php
                                            echo $empresita[0]->detalle;    
                                            ?>
                                        </td>
                                    </tr>
                                        <?php if($empresita[0]->destacado): ?> 
                                            <tr class="bg-success">
                                                <td>DESTACADO</td>
                                                    <td>
                                                        OK
                                                    </dt>
                                            </tr>        
                                        <?php else: ?>
                                            <tr class="bg-danger">
                                                <td>DESTACADO</td>
                                                    <td>
                                                        NO
                                                    </dt>
                                            </tr>    
                                        <?php endif; ?>
                                        </td>
                                    </tr>
                                    

                                    <tr>
                                        <td>CATEGORIA</td>
                                        <td><?php echo e($empresita[0]->categoria); ?></td>
                                    </tr>

                                    <tr>
                                        <td>CREADO</td>
                                        <td><?php echo e($empresita[0]->created_at); ?></td>
                                    </tr>

                                    <tr>
                                        <td>ACUALIZADO</td>
                                        <td><?php echo e($empresita[0]->updated_at); ?></td>
                                    </tr>

                                <?php if(isset($ordenes)): ?>
                                
                                    <tr class="bg-cyan">
                                        <td>FECHA INICIO VERSION PRO</td>
                                        <td>
                                            <?php echo e($ordenes->created_at); ?>

                                        </td>
                                    </tr>

                                    <tr class="bg-cyan">
                                        <td>FECHA FIN VERSION PRO</td>
                                        <td>
                                            <?php echo e($ordenes->ffin); ?>

                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <tr class="bg-warning">
                                        <td>FECHA INICIO VERSION PRO</td>
                                        <td>
                                            No tiene orden activa
                                        </td>
                                    </tr>
                                <?php endif; ?>    
                                    
                                </tbody>      

                            </table>
                            

                                <?php
                                    $i=1; // variable para crear un nuevo row o añadir a contunuacion de 4 en 4
                                ?>

                            <div class="row mb-3">

                            </div>
                <div class="text-center">
                    
                    <div class="card-header bg-cyan text-center mb-2">PRODUCTOS O SERVICIOS: <?php echo e($empresita[0]->empresa); ?></div>
                </div>                            
                            <div id="gallery">
                                <?php $__currentLoopData = $imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ima): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if((($i-1) % 4==0)||($i==1)): ?>
                                        <div class="row">
                                            <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 input-group mb-3" >
                                                <div class="card text-white mb-3" style="max-width: 36rem;">
                                                    <div class="card-header bg-cyan text-center"><?php echo e($ima->titulo); ?></div>
                                                        <div class="card-body">
                                                                <img class="img-thumbnail" src="<?php echo e(isset($ima->foto) ? Storage::url($ima->foto) : Storage::url('galerias/sinimagenes.jpg')); ?>" alt="">
                                                        </div>
                                                        <div class="text-center botonaccion">
                                                            <p class="text-gray"> <?php echo e($ima->descripcion); ?></p>
                                                        </div>
                                                </div>
                                            </div>                            
                                    <?php else: ?>    
                                        <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 input-group mb-3" >
                                            <div class="card text-white mb-3" style="max-width: 36rem;">
                                                <div class="card-header bg-cyan text-center"><?php echo e($ima->titulo); ?></div>
                                                    <div class="card-body">
                                                        <img class="img-thumbnail" src="<?php echo e(isset($ima->foto) ? Storage::url($ima->foto) : Storage::url('galerias/sinimagenes.jpg')); ?>" alt="">
                                                    </div>
                                                <div class="text-center botonaccion">
                                                    <p class="text-gray"> <?php echo e($ima->descripcion); ?></p>
                                                </div>
                                            </div>
                                        </div> 
                                        <?php if(($i) % 4 == 0): ?>
                                            </div>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <?php
                                        $i=$i+1;    
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                </div>
            </div> <!-- FIN ROW -->
        </div>


        <div class="row">
            <div class="col-lg-12">  
                <div class="card-header border-success d-flex mt-3">
                    <h3 class="card-title">NUMEROS TELEFONICOS: <strong> <?php echo e($empresita[0]->empresa); ?> </strong> </h3>
                    
                </div>
                <div class="card-body"> 
                    <table id="telofempresas" class="table table-hover table-bordered table-striped">
                        <thead class="bg-cyan">
                        
                            <th>#</th>
                            <th>Numero</th>
                            <th>Detalle</th>
                         
                            <th>Contactar</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $telefonos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $telefono): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($telefono->prefijo.$telefono->numero); ?></td>
                                    <td><?php echo e($telefono->updated_at); ?></td>
                                    <td>
                                        <a class="btn btn-success btn-sm" target="_blank" href="https://api.whatsapp.com/send?phone=<?php echo e($telefono->prefijo.$telefono->numero); ?>"><i class="fab fa-whatsapp"></i></a>
                                    </td>
                                   
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <?php echo e($telefonos->render()); ?>

            </div>
        </div> <!-- FIN ROW -->
 
<?php $__env->stopSection(); ?>


<?php $__env->startSection('codigojs'); ?>
<script src=""></script>
<script src="<?php echo e(asset("dist/js/alertas.js")); ?>"></script>
<script src="https://cdn.datatables.net/responsive/2.2.4/js/dataTables.responsive.min.js"></script>
<script type="text/javascript">


$(document).ready(function() {

    $('#telofempresas').DataTable({ 
     
       
        
        "language":{
            "search":"Buscar",
            "paginate":{
                "next":"Siguiente",
                "previous":"Anterior",
            },
            "lengthMenu": 'Mostrar <select>' +
                                    '<option value="5">5</option>'+
                                    '<option value="10">10</option>'+
                                    '<option value="20">20</option>'+
                                    '<option value="50">50</option>'+
                                    '<option value="-1">Todos</option>'+
                                    '</select> Registros',
            "loadingsRecords":"Cargando....",
            "processing":"Procesando...",
            "emptyTable":"No encontre números telefónicos",
            "infoEmpty":"",
            "infoFiltered":"",
            "zeroRecords":"No hay datos",  
            "info": "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
        },
        "responsive": true,
        columnDefs: [
            { responsivePriority: 1, targets: 0 },
            { responsivePriority: 2, targets: 1 }
        ],

    })

    $('table').on('click','.eliminar',function (e) {
        
        e.preventDefault();   
        Swal.fire({
            title: 'Estas seguro(a) de eliminar este registro?',
            text: "Si eliminas el registro no lo podras recuperar jamás!",
            icon: 'question',
            showCancelButton: true,
            showConfirmButton:true,
            confirmButtonColor: '#25ff80',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Eliminar..!',
            position:'center',        
        }).then((result) => {
            if (result.value) {
                var $form=$(this).parent();
                $form.append('<input name="_token" type="hidden" value="' + $('meta[name="csrf-token"]').attr('content') + '">');
                console.log('_token');
                $(this).parent().submit();
                Swal.fire(
                'Borrado Correctamente!',
                'El registro fue eliminado definitivamente.',
                'success')
            }else{
                const Toast = Swal.mixin({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 2000,
                    timerProgressBar: true,
                    onOpen: (toast) => {
                        toast.addEventListener('mouseenter', Swal.stopTimer)
                        toast.addEventListener('mouseleave', Swal.resumeTimer)
                    }
                })

                Toast.fire({
                    icon: 'error',
                    title: 'No se eliminó el registro'
                })
            }
        })
});


} );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\foconsito\resources\views/empresa/mostrar.blade.php ENDPATH**/ ?>