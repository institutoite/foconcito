<div class="row">
    <div class="col-3">
    </div>
    <a href="<?php echo e(route('home')); ?>" class="btn btn-danger col-2">Cancelar</a>
     <div class="col-2"></div>
    <button type="submit" class="btn btn-success btn-sm col-2">Actualizar</button>
    <div class="col-3">
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\foconsito\resources\views/includes/boton_actualizar.blade.php ENDPATH**/ ?>