
<div class="form-group">
    <label for="detalle">Nombre Mensaje</label>
    <input  type="text" name="nombre" class="form-control" value="<?php echo e(old('nombre',$mensaje_a_editar->nombre ?? '')); ?>" placeholder="ingrese un  nombre de mensaje a">
    <small id="nombreHelp" class="form-text text-muted">Favor introduzca nombre para el mensaje</small>
</div>

<div class="form-group">
    <label for="detalle">Mensaje</label>
    <textarea class="emojionearea mb-3 mensaje" name="mensaje" id="mensaje" cols="80">
        <?php echo e(old('mensaje',$mensaje_a_editar->mensaje ?? '')); ?>

    </textarea>
    <small id="nombreHelp" class="form-text text-muted">Favor introduzca un mensaje</small>
</div>
<?php /**PATH C:\xampp\htdocs\foconsito\resources\views/mensaje/form.blade.php ENDPATH**/ ?>