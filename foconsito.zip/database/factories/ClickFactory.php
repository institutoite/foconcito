<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Click;
use Faker\Generator as Faker;

$factory->define(Click::class, function (Faker $faker) {
    return [
        //
    ];
});
