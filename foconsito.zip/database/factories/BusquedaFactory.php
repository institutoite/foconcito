<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Busqueda;
use Faker\Generator as Faker;

$factory->define(Busqueda::class, function (Faker $faker) {
    return [
        //
    ];
});
