<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Pais;
use Faker\Generator as Faker;

/*$factory->define(Pais::class, function (Faker $faker) {
    return [
        //
    ];
});*/
