<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Zona;
use Faker\Generator as Faker;

$factory->define(Zona::class, function (Faker $faker) {
    return [
        //
    ];
});
