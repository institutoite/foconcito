<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Metodopago;
use Faker\Generator as Faker;

$factory->define(Metodopago::class, function (Faker $faker) {
    return [
        //
    ];
});
