<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Potencialidad;
use Faker\Generator as Faker;

$factory->define(Potencialidad::class, function (Faker $faker) {
    return [
        //
    ];
});
