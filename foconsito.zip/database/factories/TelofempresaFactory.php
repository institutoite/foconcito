<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Telofempresa;
use Faker\Generator as Faker;

$factory->define(Telofempresa::class, function (Faker $faker) {
    return [
        //
    ];
});
