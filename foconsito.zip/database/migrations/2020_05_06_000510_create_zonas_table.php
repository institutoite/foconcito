<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateZonasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('zonas', function (Blueprint $table) {
           $table->increments('id');
            $table->string('zona', 100)->nullable();
            
            $table->unsignedInteger('ciudad_id');
             $table->foreign('ciudad_id','fk_ciudad_zona')
                        ->references('id')->on('ciudads');

           /* $table->unsignedInteger('user_id');
            $table->foreign('user_id','fk_users_zonas')
                        ->references('id')->on('users');*/
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('zonas');
    }
}
